#include<stdio.h>

int main() {
    int a = 15;
    printf("%d \n",++a);
    printf("%d \n",a++);
    printf("%d \n",--a);
    printf("%d \n",a--);

    return 0;
}