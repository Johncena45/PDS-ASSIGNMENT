#include <stdio.h>

int main() {
    int num;

    printf("Input a number: ");
    scanf("%d", &num);

    // Condition: (num % 2 != 0) checks if the number is odd
    // Condition: (num >= 100 && num <= 200) checks if the number is within the range [100, 200]
    int result = (num % 2 != 0 && num >= 100 && num <= 200);

    printf(result ? "True\n" : "False\n");

    return 0;
}