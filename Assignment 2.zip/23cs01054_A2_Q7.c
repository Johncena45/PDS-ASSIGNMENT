#include <stdio.h>
#include <math.h>

int main() {
    double meal_cost, tip_percent, tax_percent;
    
    printf("Enter the meal cost: ");
    scanf("%lf", &meal_cost);
    
    printf("Enter the tip percent: ");
    scanf("%lf", &tip_percent);
    
    printf("Enter the tax percent: ");
    scanf("%lf", &tax_percent);
    
    double tip = meal_cost * (tip_percent / 100);
    double tax = meal_cost * (tax_percent / 100);
    
    double total_cost = meal_cost + tip + tax;
    
    // Rounding the total cost to the nearest integer
    int rounded_total_cost = (int)round(total_cost);
    
    printf("The total cost of the meal is: %d\n", rounded_total_cost);
    
    return 0;
}