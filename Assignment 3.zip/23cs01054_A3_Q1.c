 #include<stdio.h>
 int main(){
    int x;

    printf("Enter a number:\n");
    scanf("%d",&x);

    if (x>0) {
        printf("The entered number is positive.\n");
    }
    else if (x<0){
        printf("The entered number is negative.\n");         
    }
    else{
        printf("The entered number is zero.\n");
    }
    return 0;
 }