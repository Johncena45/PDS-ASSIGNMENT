#include<stdio.h>
int main(){
    
    int a,b,c;
    printf("Enter three numbers:\n");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);

    if (a+b>c&&b+c>a&&c+a>b){
        printf("Yes,%d,%d and %d can form the sides of a triangle\n",a,b,c);
    }
    else{
        printf("No,%d,%d and %d cannot form the sides of a triangle\n",a,b,c);
    }
    return 0;
}