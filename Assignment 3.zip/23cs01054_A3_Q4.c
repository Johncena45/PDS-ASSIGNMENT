#include<stdio.h>
int main(){
    
    int x1,y1,x2,y2,x3,y3;
    printf("Enter six numbers:\n");
    scanf("%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&x3,&y3);

    if ((y2-y1)*(x3-x2)==(x2-x1)*(y3-y2)){
        printf("(%d,%d),(%d,%d) and (%d,%d) are collinear\n",x1,y1,x2,y2,x3,y3);
    } 
    else{
        printf("(%d,%d),(%d,%d) and (%d,%d) are not collinear\n",x1,y1,x2,y2,x3,y3);
    }
}