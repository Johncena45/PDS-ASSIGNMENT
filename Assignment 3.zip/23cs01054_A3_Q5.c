#include<stdio.h>
int main(){
int day;
printf("enter the days:\n");
scanf("%d",&day);
if(day<=5)
printf("your fine is 1 rupee.\n");
else if(day>=6&&day<=10)
printf("your fine is 2 rupees.\n");
else if(day>10&&day<=30)
printf("your fine is 5 rupees.\n");
else if(day>30)  {

    printf("your membership is cancelled");
}
    return 0;
}


