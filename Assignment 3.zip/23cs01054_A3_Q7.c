#include<stdio.h>
int main(){

float T,M,W;
int N,K ;
printf("Enter the values of M,N,K\n");  /*M--->Marks obtained//W--->Attendance weight//k--->total no. of classes conducted*/
scanf("%f%d%d",&M,&N,&K);
W = N/K;
T = M*W;                              /*T--->Final score//N--->Number of classes Attended*/
if(T>=90)
printf("your grade is EX\n");
if( T>=80&&T<89)
printf("your grade is A\n");
else if(T>=70&&T<79)
printf("your grade is B\n");
else if(T>=60&&T<69)
printf("your grade is C\n");
else if(T>=50&&T<59)
printf("your grade is D\n");
else if(T>=40&&T<49)
printf("your grade is P\n");
else if (T<40)
printf("your grade is F\n");
    return 0;
}