#include<stdio.h>
int main(){
    int i;
    printf("Enter an integer:\n");
    scanf("%d",&i);
    switch (i%2)
    { 
        case 0:
            printf("%d is an even number",i);
            break;
        case 1:
            printf("%d is an odd number",i);
            break;
        default:
            printf("Invalid input");     
    }
    return 0;
}