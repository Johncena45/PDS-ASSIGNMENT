#include<stdio.h>
int main (){

    int a,b,c;
    printf("Enter three integers:\n");
    scanf("%d",&a);
    scanf("%d",&b);
    scanf("%d",&c);

    if (a>b&&a>c){
        printf("%d is the largest integer\n",a);
    }
    else if (b>c){
        printf("%d is the largest integer\n",b);
    }
    else{
        printf("%d is the largest integer\n",c);
    }
    return 0 ;  
    }