#include<stdio.h>
int main(){
    
    int credit_score;
    double credit_card_balance;

    printf("Enter your credit score:\n");
    scanf("%d",&credit_score);

    printf("Enter your credit_card_balance:\n");
    scanf("%lf",&credit_card_balance);

    int interest_rate;

    if (credit_score<=600) {
        interest_rate=15;
    }
    else if (credit_score<=750) {
        interest_rate=12;
    }
    else {
        interest_rate=10;
    }
    double calculated_interest = interest_rate * (credit_card_balance/100);   
    
    printf("The calculated interest is : %.2lf\n",calculated_interest);

    return 0;
}