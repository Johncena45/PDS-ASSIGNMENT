#include<stdio.h>
#include<math.h>
int main(){

    int a;
    printf("Enter an Integer:\n");
    scanf("%d",&a);

    int b=a%10;
    int c=(a/10)%10;
    int d=a/100;
    int p=pow(b,3)+pow(c,3)+pow(d,3);

    if (p==a&&100<=a&&a<=999){
        printf("Yes,%d is an Armstrong number",a);

    }
    else if (100<=a&&a<=999){
        printf("No,%d is not an Armstrong number",a);
   
    }
    else {
        printf("Incorrect Input");
    }

    return 0;

}
