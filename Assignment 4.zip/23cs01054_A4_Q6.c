#include <stdio.h>

int main() {

    int num1, num2, result;

    printf("Enter two integers:\n");
    scanf("%d %d", &num1, &num2);
   
    char operator;
    printf("Enter operator (+, -, *, /):\n");
    scanf(" %c", &operator);

    switch(operator) {
        case '+':
            result = num1 + num2;
            break;
        case '-':
            result = num1 - num2;
            break;
        case '*':
            result = num1 * num2;
            break;
        case '/':
            if (num2 != 0)
                result = num1 / num2;
            else {
                printf("Error! Cannot divide by zero");
            }
            break;
        default:
            printf("Error! Invalid operator.");
            break; 
    }


    printf("Result: %d\n", result);

    return 0; 
}