#include<stdio.h>
int main (){
    
    int age;

    printf("Please enter your age:\n");
    scanf("%d",age);
    
    if (age<5){
        printf("Ticket price:Rs.0");
    }
    else if (age<13){
        printf("Tictet price:Rs.20");
    }
    else if (age<60){
        printf("Ticket price:Rs.50");
    }
    else {
        printf("Ticket price:Rs.40");
    }
}