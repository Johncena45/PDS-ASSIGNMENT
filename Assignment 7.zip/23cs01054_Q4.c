#include<stdio.h>
int fun(int a[],int len,int max){

    if(len==1){
        return max;
    }
    if(max>a[len-1]){
        return fun(a,len-1,max);
    }
    else{
        return fun(a,len-1,a[len-1]);
    }
}
int main(){
    int arr[6] = {12,23,45,56,67,54};
    int len = sizeof(arr)/sizeof(arr[0]);
    int max = arr[0];
    max = fun(arr,len,max);
    printf("%d",max);
    return 0;
}