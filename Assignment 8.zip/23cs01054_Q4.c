#include <stdio.h>
#include <stdbool.h>

void printDuplicates(int *nums, int n) {
    bool *visited = calloc(n + 1, sizeof(bool));
    
    printf("Duplicate numbers in the array: ");
    for (int i = 0; i < n + 1; i++) {
        if (visited[nums[i]]) {
            printf("%d ", nums[i]);
        } else {
            visited[nums[i]] = true;
        }
    }
    
    free(visited);
}

int main() {
    int nums[] = {3, 1, 4, 2, 1, 5}; // Example array
    int n = sizeof(nums) / sizeof(nums[0]) - 1; // Size of the array
    
    printDuplicates(nums, n);

    return 0;
}