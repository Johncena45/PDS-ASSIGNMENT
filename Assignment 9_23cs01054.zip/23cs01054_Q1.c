#include <stdio.h>

// Define the structure
struct company {
    char name[100];
    char address[100];
    char phone[15]; // Assuming phone number can be 15 characters long (including country code)
    int noOfEmployee;
};

int main() {
    // Declare a variable of type company
    struct company comp;

    // Read input for company details
    printf("Enter the name of the company: ");
    scanf("%99[^\n]%*c", comp.name); // Read up to 99 characters until newline, discard newline

    printf("Enter the address of the company: ");
    scanf("%99[^\n]%*c", comp.address);

    printf("Enter the phone number of the company: ");
    scanf("%14s", comp.phone); // Read up to 14 characters for phone number (excluding null terminator)

    printf("Enter the number of employees in the company: ");
    scanf("%d", &comp.noOfEmployee);

    // Display company details
    printf("\nCompany Details:\n");
    printf("Name: %s\n", comp.name);
    printf("Address: %s\n", comp.address);
    printf("Phone: %s\n", comp.phone);
    printf("Number of Employees: %d\n", comp.noOfEmployee);

    return 0;
}