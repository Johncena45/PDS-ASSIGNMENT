#include <stdio.h>

// Define a structure for Address
struct Address {
    char street[100];
    char city[50];
    char zipCode[20];
};

// Define a structure for Person
struct Person {
    char name[100];
    struct Address address;
};

int main() {
    // Create a Person variable
    struct Person person1;

    // Set details for person1
    printf("Enter name: ");
    scanf("%99[^\n]%*c", person1.name); // Read up to 99 characters until newline, discard newline
    
    printf("Enter street: ");
    scanf("%99[^\n]%*c", person1.address.street);
    
    printf("Enter city: ");
    scanf("%49[^\n]%*c", person1.address.city);
    
    printf("Enter zip code: ");
    scanf("%19[^\n]%*c", person1.address.zipCode);

    // Print details of person1
    printf("\nDetails of Person:\n");
    printf("Name: %s\n", person1.name);
    printf("Street: %s\n", person1.address.street);
    printf("City: %s\n", person1.address.city);
    printf("Zip Code: %s\n", person1.address.zipCode);

    return 0;
}