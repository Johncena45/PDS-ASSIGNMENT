#include <stdio.h>
#include <stdbool.h>

// Define a structure for CourseRecord
struct CourseRecord {
    char firstName[50];
    char lastName[50];
    int rollNumber;
    char department[50];
    char courseCode[20];
    float testMarks[3];
};

// Function to calculate average test marks for a CourseRecord
float calculateAverageTestMarks(struct CourseRecord record) {
    float sum = 0;
    for (int i = 0; i < 3; i++) {
        sum += record.testMarks[i];
    }
    return sum / 3.0;
}

// Function to determine if a student passes the test
bool isPass(struct CourseRecord record) {
    float averageMarks = calculateAverageTestMarks(record);
    return averageMarks >= 50.0; // Assuming passing marks are 50
}

int main() {
    // Example usage
    struct CourseRecord studentRecord = {
        "John",
        "Doe",
        123456,
        "Computer Science",
        "CS101",
        {75, 80, 65} // Test marks
    };

    printf("Average Test Marks: %.2f\n", calculateAverageTestMarks(studentRecord));

    if (isPass(studentRecord)) {
        printf("Student passed the test.\n");
    } else {
        printf("Student failed the test.\n");
    }

    return 0;
}