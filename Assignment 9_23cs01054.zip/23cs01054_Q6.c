#include <stdio.h>
#include <string.h>
#include <math.h>

#define MAX_RECORDS 100

// Define a structure for student record
struct StudentRecord {
    char name[50];
    int rollNumber;
    float percentage;
};

// Global array to store student records
struct StudentRecord database[MAX_RECORDS];
int numRecords = 0;

// Function to insert a record into the database
void insert(char name[], int rollNumber, float percentage) {
    // Check if there is space in the database
    if (numRecords >= MAX_RECORDS) {
        printf("Database is full. Cannot insert more records.\n");
        return;
    }
    
    // Find the position to insert the record in sorted order by roll number
    int i;
    for (i = numRecords - 1; i >= 0 && database[i].rollNumber > rollNumber; i--) {
        database[i + 1] = database[i]; // Shift records to make space for the new record
    }
    
    // Insert the new record
    strcpy(database[i + 1].name, name);
    database[i + 1].rollNumber = rollNumber;
    database[i + 1].percentage = percentage;
    
    numRecords++;
}

// Function to sort the database according to the name
void sortName() {
    struct StudentRecord temp;
    int i, j;
    for (i = 0; i < numRecords - 1; i++) {
        for (j = 0; j < numRecords - i - 1; j++) {
            if (strcmp(database[j].name, database[j + 1].name) > 0) {
                temp = database[j];
                database[j] = database[j + 1];
                database[j + 1] = temp;
            }
        }
    }
}

// Function to find one name from the database that starts with the given prefix
char* findOne(char prefix[]) {
    for (int i = 0; i < numRecords; i++) {
        if (strncmp(database[i].name, prefix, strlen(prefix)) == 0) {
            return database[i].name;
        }
    }
    return "Not found";
}

// Function to calculate the mean of percentages in the database
float calculateMean() {
    float sum = 0;
    for (int i = 0; i < numRecords; i++) {
        sum += database[i].percentage;
    }
    return sum / numRecords;
}

// Function to calculate the standard deviation of percentages in the database
float calculateStandardDeviation(float mean) {
    float sum = 0;
    for (int i = 0; i < numRecords; i++) {
        sum += pow(database[i].percentage - mean, 2);
    }
    return sqrt(sum / numRecords);
}

// Function to return an array containing various statistics
float* specs() {
    static float statistics[5];
    float mean = calculateMean();
    float maxPercentage = database[0].percentage;
    float minPercentage = database[0].percentage;
    float standardDeviation = calculateStandardDeviation(mean);

    for (int i = 0; i < numRecords; i++) {
        if (database[i].percentage > maxPercentage) {
            maxPercentage = database[i].percentage;
        }
        if (database[i].percentage < minPercentage) {
            minPercentage = database[i].percentage;
        }
    }

    statistics[0] = numRecords;
    statistics[1] = maxPercentage;
    statistics[2] = minPercentage;
    statistics[3] = mean;
    statistics[4] = standardDeviation;

    return statistics;
}

// Function to delete a record with given roll number
void deleteRecord(int rollNumber) {
    int i, j;
    for (i = 0; i < numRecords; i++) {
        if (database[i].rollNumber == rollNumber) {
            for (j = i; j < numRecords - 1; j++) {
                database[j] = database[j + 1];
            }
            numRecords--;
            printf("Record with roll number %d deleted successfully.\n", rollNumber);
            return;
        }
    }
    printf("Record with roll number %d not found.\n", rollNumber);
}

int main() {
    // Example usage
    insert("John Doe", 101, 85.5);
    insert("Alice Smith", 102, 78.9);
    insert("Bob Johnson", 103, 92.3);

    sortName();

    printf("Sorted Database by Name:\n");
    for (int i = 0; i < numRecords; i++) {
        printf("Name: %s, Roll Number: %d, Percentage: %.2f\n", database[i].name, database[i].rollNumber, database[i].percentage);
    }

    char* foundName = findOne("Al");
    printf("Name found with prefix 'Al': %s\n", foundName);

    float* statistics = specs();
    printf("\nDatabase Statistics:\n");
    printf("Number of Records: %.0f\n", statistics[0]);
    printf("Highest Percentage: %.2f\n", statistics[1]);
    printf("Lowest Percentage: %.2f\n", statistics[2]);
    printf("Mean Percentage: %.2f\n", statistics[3]);
    printf("Standard Deviation: %.2f\n", statistics[4]);

    deleteRecord(102);

    return 0;
}