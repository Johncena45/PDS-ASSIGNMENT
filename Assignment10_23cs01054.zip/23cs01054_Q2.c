#include <stdio.h>

// Define a structure named StructData
struct StructData {
    int integer1;
    int integer2;
    char character;
};

// Define a union named UnionData
union UnionData {
    int integer1;
    int integer2;
    char character;
};

int main() {
    struct StructData structVar;
    union UnionData unionVar;

    printf("Size of struct StructData: %lu bytes\n", sizeof(struct StructData));
    printf("Size of union UnionData: %lu bytes\n", sizeof(union UnionData));

    return 0;
}