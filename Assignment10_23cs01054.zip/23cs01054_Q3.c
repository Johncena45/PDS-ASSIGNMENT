#include <stdio.h>

// Define a union named EmpDetails
union EmpDetails {
    float hourly_wage;
    double fixed_salary;
};

// Define a structure named Employee
struct Employee {
    int id;
    char name[50];
    union EmpDetails details;
};

int main() {
    // Declare an Employee variable
    struct Employee emp;

    // Assign values to the elements of the Employee structure
    emp.id = 1001;
    snprintf(emp.name, sizeof(emp.name), "John Doe");
    emp.details.hourly_wage = 15.50; // Assign hourly wage
    // Or assign fixed salary
    // emp.details.fixed_salary = 40000.00;

    // Access and print the elements of the Employee structure
    printf("Employee ID: %d\n", emp.id);
    printf("Employee Name: %s\n", emp.name);
    printf("Employee Hourly Wage: %.2f\n", emp.details.hourly_wage);
    // Or access fixed salary
    // printf("Employee Fixed Salary: %.2f\n", emp.details.fixed_salary);

    return 0;
}