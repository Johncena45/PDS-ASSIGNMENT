#include <stdio.h>

#define MAX_SIZE 5

// Define a union named ArrayUnion
union ArrayUnion {
    int int_array[MAX_SIZE];
    float float_array[MAX_SIZE];
    char char_array[MAX_SIZE];
};

int main() {
    union ArrayUnion arr_union;

    // Assign values to the integer array
    for (int i = 0; i < MAX_SIZE; i++) {
        arr_union.int_array[i] = i + 1;
    }

    // Access and print the integer array values
    printf("Integer array values: ");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%d ", arr_union.int_array[i]);
    }
    printf("\n");

    // Assign values to the float array
    for (int i = 0; i < MAX_SIZE; i++) {
        arr_union.float_array[i] = (float)(i + 1) * 1.5;
    }

    // Access and print the float array values
    printf("Float array values: ");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%.2f ", arr_union.float_array[i]);
    }
    printf("\n");

    // Assign values to the character array
    for (int i = 0; i < MAX_SIZE; i++) {
        arr_union.char_array[i] = 'A' + i;
    }

    // Access and print the character array values
    printf("Character array values: ");
    for (int i = 0; i < MAX_SIZE; i++) {
        printf("%c ", arr_union.char_array[i]);
    }
    printf("\n");

    return 0;
}