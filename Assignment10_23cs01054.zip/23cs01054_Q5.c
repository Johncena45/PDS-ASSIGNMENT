#include <stdio.h>

// Enumeration for pay types
enum PayType {
    HOURLY,
    SALARY
};

// Define a union named EmpDetails
union EmpDetails {
    float hourly_wage;
    double fixed_salary;
};

// Define a structure named Employee
struct Employee {
    int id;
    char name[50];
    enum PayType pay_type;
    union EmpDetails details;
};

int main() {
    // Declare an Employee variable
    struct Employee emp;

    // Assign values to the elements of the Employee structure
    emp.id = 1001;
    snprintf(emp.name, sizeof(emp.name), "John Doe");
    emp.pay_type = SALARY;
    
    // Assign appropriate values based on the pay type
    switch (emp.pay_type) {
        case HOURLY:
            emp.details.hourly_wage = 15.50; // Assign hourly wage
            break;
        case SALARY:
            emp.details.fixed_salary = 40000.00; // Assign fixed salary
            break;
    }

    // Access and print the elements of the Employee structure
    printf("Employee ID: %d\n", emp.id);
    printf("Employee Name: %s\n", emp.name);
    printf("Employee Pay Type: %s\n", emp.pay_type == HOURLY ? "Hourly" : "Salary");
    if (emp.pay_type == HOURLY) {
        printf("Employee Hourly Wage: %.2f\n", emp.details.hourly_wage);
    } else {
        printf("Employee Fixed Salary: %.2f\n", emp.details.fixed_salary);
    }

    return 0;
}