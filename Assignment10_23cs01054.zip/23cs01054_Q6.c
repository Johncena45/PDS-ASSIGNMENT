#include <stdio.h>
#include <string.h>

#define MAX_STRING_LENGTH 100

// Define a union named Packet
union Packet {
    struct {
        int opcode;
        int status_code;
    } control_message;
    char data_payload[MAX_STRING_LENGTH];
};

// Enumeration for packet types
enum PacketType {
    CONTROL,
    DATA
};

// Define a structure named DataPacket
struct DataPacket {
    enum PacketType type;
    union Packet packet;
};

// Function to assign values to a control message packet
void assignControlPacket(struct DataPacket *packet, int opcode, int status_code) {
    packet->type = CONTROL;
    packet->packet.control_message.opcode = opcode;
    packet->packet.control_message.status_code = status_code;
}

// Function to assign values to a data packet
void assignDataPacket(struct DataPacket *packet, const char *data) {
    packet->type = DATA;
    strncpy(packet->packet.data_payload, data, MAX_STRING_LENGTH);
}

// Function to print packet contents
void printPacket(const struct DataPacket *packet) {
    switch (packet->type) {
        case CONTROL:
            printf("Control Packet:\n");
            printf("Opcode: %d\n", packet->packet.control_message.opcode);
            printf("Status Code: %d\n", packet->packet.control_message.status_code);
            break;
        case DATA:
            printf("Data Packet:\n");
            printf("Data Payload: %s\n", packet->packet.data_payload);
            break;
    }
}

int main() {
    // Create an array of DataPacket
    struct DataPacket packets[2];

    // Assign values to demonstrate control and data packets
    assignControlPacket(&packets[0], 1, 200);
    assignDataPacket(&packets[1], "Hello, world!");

    // Print packet contents
    for (int i = 0; i < 2; ++i) {
        printPacket(&packets[i]);
    }

    return 0;
}