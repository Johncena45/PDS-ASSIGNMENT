#include<stdio.h>
#include<math.h>

#define pi 3.14
int main(){

    float radius,volume,surface_area;
    printf("Enter the radius:");
    scanf("%f",&radius);

    volume = (4.0/3.0)*pi*radius*radius*radius;
    surface_area = 4*pi*radius*radius;

    printf("Volume of sphere is %.2f\n",volume);
    printf("Surface area of sphere is %.2f\n",surface_area);

    return 0;

}