#include<stdio.h>


 int fact(int a)
 {
     
    int facta=1;
    int fact;
    for (fact=a;fact>0;fact--){
        facta=facta*fact;
    }

    return facta;
 }

 int main(){

    int num;
    printf("Enter a number:");
    scanf("%d",&num);
    
    int a;
    int result = 0;
    int b = num;
    
    for(num;num!=0;num = num/10){
        a = num%10;

        result = result+fact(a);
               
    }
    
    if (result==b){
        printf("%d is a strong number",b);
    }
    else {
        printf("%d is not a strong number",b);
    }
    return 0;
 }