#include <stdio.h>
#include<math.h>

int main(){
    int a,b,c;
    float determinant;
    printf("Enter A,B,C in order(Ax^2+Bx+C): ");
    scanf("%d%d%d",&a,&b,&c);
    determinant = ((b*b)-(4*a*c));
    if(determinant>=0){
        printf("\n The real roots are :");
        printf("\n%f",(pow(determinant,0.5)-b)/(2*a));
        printf("\n%f",(-pow(determinant,0.5)-b)/(2*a)); 

    }
    else{
        printf("\n The imaginary roots are :");
        printf("\n%f+%fi",((float)(-b))/(2*a),(pow((-determinant),0.5))/(2*a));
        printf("\n%f-%fi",((float)(-b))/(2*a),(pow((-determinant),0.5))/(2*a));

    }
   
    

return 0;

}